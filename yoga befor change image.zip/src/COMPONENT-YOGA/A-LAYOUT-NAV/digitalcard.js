export default function Contact() {
  return (
    <div>
      <h1>Contact Page</h1>
      <p>This is your digital visiting card contact page.</p>
    </div>
  );
}
